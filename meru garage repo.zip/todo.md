# TODO

Tick each item only after it is built, run and tested. Feature IDs match docs/AI_PROMPT.md.

## Foundation
- [ ] F45 Database schema, migrations, indexes, transactions
- [ ] F46 Seed 5,000+ parts
- [ ] F32 Roles and token verification
- [ ] F04 Login: phone OTP, Google, email, biometrics
- [ ] F47 Logging, error boundaries, global handlers
- [ ] F48 Timeouts, retries, circuit breakers, idempotency

## Design and app shell
- [ ] F01 Design system and themes
- [ ] F02 Logo, icons, glass UI, animated background
- [ ] F03 Animated bottom navigation
- [ ] F05 Home screen
- [ ] F28 Settings
- [ ] F29 English, Swahili, KES, USD
- [ ] F52 Accessibility

## Store
- [ ] F06 Catalog, categories, filters
- [ ] F07 Search (name, part number, VIN, vehicle, photo)
- [ ] F08 Product page and authenticity
- [ ] F09 Reviews, related, discounts, bundles, compare
- [ ] F10 Wishlist
- [ ] F11 Cart and checkout
- [ ] F12 M-Pesa and cash on delivery
- [ ] F13 Orders, tracking, returns
- [ ] F14 PDF receipts by WhatsApp and email
- [ ] F15 Garage vehicles and VIN decoder
- [ ] F41 CSV import and barcode stock

## AI and agents
- [ ] F16 AI support bot
- [ ] F17 Diagnostic agent
- [ ] F18 Agents hub page
- [ ] F19 Decision engine
- [ ] F20 Seven agents
- [ ] F21 Approval queue
- [ ] F22 Job queue and workers
- [ ] F23 Load balancing, failover, monitoring
- [ ] F59 Self-diagnostic and self-healing

## Content and tools
- [ ] F24 Live news
- [ ] F25 About with videos
- [ ] F26 Notifications
- [ ] F27 Tools (reminders, booking, checklists, estimator, tyre and oil guide)
- [ ] F30 Offline cache and sync

## Security
- [ ] F31 Encryption
- [ ] F33 Validation, headers, CORS, rate limiting, bot blocking, CSRF, XSS
- [ ] F34 Device checks, session rotation, admin 2FA
- [ ] F35 Upload malware scan
- [ ] F36 Fraud detection and attack response
- [ ] F37 Backups and restore
- [ ] F38 Data protection: consent, export, delete

## Admin
- [ ] F39 Dashboards and reports
- [ ] F40 Management screens
- [ ] F42 Audit trail
- [ ] F43 Alerts and exports
- [ ] F44 In-app admin

## Quality and release
- [ ] F49 Tests
- [ ] F50 Load test
- [ ] F51 CI pipeline
- [ ] F53 Web build
- [ ] F54 Android build and Play Store steps
- [ ] F55 Deployment (Supabase, Vercel)
- [ ] F56 .env.example, SETUP.md, DEPLOY.md
- [ ] F57 BUILD_STATE.md and DECISIONS.md current
- [ ] F58 Performance targets
- [ ] F60 Final verification table

## Phase 2 (after launch)
- [ ] Wholesale portal and fleet accounts
- [ ] iOS App Store release
- [ ] Real-time backups
