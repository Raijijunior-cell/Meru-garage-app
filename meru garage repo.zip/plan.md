# PLAN

How every feature is built. Feature IDs match TODO.md. Free-tier tools only.

## 1. System map

```
Mobile/Web (Expo) -> Edge/CDN (Vercel) -> API (Express) -> Brain -> Agents/Workers -> Postgres (Supabase)
                                              |                        |
                                   Auth (Clerk), Cache, Queue     Storage, Logs, Audit
External: Daraja M-Pesa, WhatsApp Cloud API, AI API, RSS/News API, SMTP, FCM/APNs
```

Flow rule: every request passes Security layer, then Brain (rules first, AI second), then Service, then Audit log.

## 2. Tools

| Layer | Tool |
|---|---|
| App | Expo, expo-router, TypeScript, react-native-reanimated, @shopify/react-native-skia (animated background), expo-blur (glass), lottie or custom SVG morph (icons) |
| App device | expo-local-authentication, expo-camera, expo-av, expo-notifications, expo-sqlite (offline), react-native-ble-plx (OBD) |
| API | Express, Zod, helmet, cors, express-rate-limit, pino (logs) |
| Data | Postgres on Supabase, Drizzle, pg_trgm and full-text search, pgvector (embeddings) |
| Queue | pg-boss (queue inside Postgres, no Redis needed) |
| Auth | Clerk (OTP, Google, email), custom RBAC |
| Payments | Daraja STK push |
| Messaging | WhatsApp Cloud API, SMTP, Expo push |
| Files | Supabase Storage, file-type sniffing, size limits, optional VirusTotal scan |
| Docs | pdfkit (receipts), exceljs (exports) |
| News | rss-parser plus news API |
| Tests | Vitest, Supertest, k6 (load) |
| Ops | GitHub Actions, Sentry free tier, Vercel, Supabase backups |

## 3. Brain (decision engine)

Single module `brain` used by support bot, diagnostics and agents.

Pipeline for every AI-type request:
1. Normalize: detect language (English, Swahili), clean text, extract entities (part numbers, VIN, vehicle, order IDs).
2. Intent classify by rules: keyword and regex map (order_status, find_part, diagnose, price, return, human). Confidence score 0 to 1.
3. If confidence at least 0.8: run deterministic handler (database lookup, template reply). No AI call.
4. Else check answer cache (hash of normalized question plus language). Hit returns cached reply.
5. Else check user AI quota. Over quota returns rules fallback plus offer of human.
6. Else call AI with strict system prompt, retrieved context (top parts, order data, FAQ via pgvector), output schema validated by Zod. Invalid output retries once, then rules fallback.
7. Safety filter: no unverified prices, no invented parts, no private data of others.
8. Store answer in cache and write audit record (input hash, route taken, cost, latency).

Escalation to human when: confidence low twice, user asks, anger detected, payment or refund topic. Ticket created with context.

## 4. Server logic

Middleware order: request ID, helmet, CORS, body limit, rate limit, bot check, Clerk token verify, RBAC, Zod validate, handler, audit, error handler.

Structure: routes, controllers, services, repositories, brain, agents, workers, integrations, shared.

Load balancing and scale: Vercel serverless auto-scales; stateless API; DB via pooled connection (Supabase pooler); heavy work goes to the pg-boss queue, not request thread. Health endpoints `/health` and `/ready`; failover: if primary AI or provider fails, use secondary or rules.

Idempotency: every payment and order request carries an idempotency key stored with unique constraint.

## 5. Algorithms

- **Search ranking:** score = 0.4 text match (tsvector rank) + 0.25 trigram similarity (typo tolerance) + 0.15 exact part-number match boost + 0.1 vehicle fitment match + 0.1 stock and popularity. Part number and VIN queries bypass text and go exact.
- **Fitment:** VIN decode gives make, model, year; filter parts by fitment table join.
- **Recommendations:** related parts by shared category and fitment, then "bought together" by order co-occurrence count; fallback to popular.
- **Diagnostic scoring:** symptom rules table (symptom, cause, weight, urgency, part category). Sum weights per cause, normalize to probability, show top 3. AI refines only when rules score is under threshold or input is photo or sound. Urgency = max urgency among top causes (low, medium, high, do not drive).
- **Stock forecast:** moving average of last 28 days of sales per part; reorder point = daily average x lead time days + safety stock; Stock agent alerts when stock is below reorder point.
- **Pricing and discounts:** rule engine (percentage, bundle, wholesale tier, fleet tier); prices stored in KES, USD derived from a stored daily rate.
- **Fraud score:** additive score from signals: velocity (orders per hour), new device, address mismatch, failed payments, unusual amount vs history. Under 30 allow, 30 to 60 review queue, over 60 hold order and alert.
- **Rate limiting:** token bucket per user and per IP; stricter on login, OTP, payment, AI endpoints. Repeated violations raise a block score; over threshold triggers IP block.
- **Caching:** cache catalog and search results (short TTL), AI answers (long TTL), invalidate on stock or price change.
- **Retry:** exponential backoff with jitter, max 5, then dead-letter queue.
- **Circuit breaker:** open after 5 failures in 60 seconds, half-open probe after 30 seconds.
- **Offline sync:** local queue of actions with client timestamps; server applies in order; conflicts resolved by server-authoritative stock and price, last-write-wins for profile.

## 6. Agents

Each agent: schedule or trigger, inputs, allowed actions, risk level, log record.

| Agent | Trigger | Does | Authority |
|---|---|---|---|
| Sales | hourly | trends, abandoned carts, suggests discounts | suggest only for price, auto for reminders |
| Stock | every 15 min | forecasts, low stock alerts, reorder drafts | auto alerts, approval for purchase |
| Support | on message | runs brain, handover, ticket triage | auto answers, approval for refunds |
| Fraud | on order and login | scores, holds, flags | auto hold, approval to block user |
| Security | continuous | reads security events, blocks IPs, locks accounts | auto low risk, approval for permanent bans |
| Reports | daily | builds sales, stock, security, bot health reports | auto |
| Diagnostics | on request | runs diagnostic scoring | auto |

Approval queue table: id, agent, action, risk, payload, status, decided_by. High-risk actions wait there.

## 7. Feature how-to

**Design (F01-F03, F28, F52):** tokens file (colors black #050505 and white #FFFFFF, greys), theme provider with dark, light, system. Glass = expo-blur panels with semi-transparent fill and thin border. Background = Skia canvas drawing slowly rotating gears and engine lines at low frame cost; pause when app is backgrounded; static image on low-end devices. Icons = SVG paths with reanimated interpolation between two states. Logo = SVG, animated stroke draw on launch. Respect reduced-motion.

**Auth (F04, F32, F34):** Clerk sign-in flows; biometric unlock via expo-local-authentication after first login; API verifies Clerk JWT; role stored in users table; admin 2FA required; refresh and rotate sessions; device record per login.

**Catalog and search (F06-F09, F46):** parts, categories, brands, fitment tables; generated seed of 5,000+ parts via script; tsvector column with GIN index and pg_trgm index; endpoint with filters and cursor pagination; product page shows authenticity code check endpoint, warranty, verified badge; reviews only from verified purchasers.

**Cart, checkout, payments (F10-F14):** server-side cart; checkout creates order in a transaction (reserve stock, create payment row pending); STK push; callback endpoint verifies source and amount, marks paid; reconcile job queries pending payments every 5 minutes; COD sets order to pending confirmation; receipt PDF via pdfkit, sent through WhatsApp and email; returns endpoint valid within 7 days, creates return ticket and restock rule.

**Vehicles and VIN (F15):** VIN validation (length, checksum), decoder via free public decoder with local cache; saved vehicles filter store fitment.

**AI support (F16):** uses brain pipeline; conversation stored in chat_messages; Swahili and English templates; human handover creates ticket and notifies support agent role.

**Diagnostics (F17):** input screens for text, photo (expo-camera), warning-light picker (icon grid), sound (expo-av record, upload, AI analysis), OBD (BLE ELM327, read DTC codes, map codes to causes table); output card with causes, urgency, linked parts, book-visit button.

**Agents hub (F18, F20, F21):** screen lists agents, status from heartbeat table, last actions; admin sees approval queue.

**Workers (F22, F23, F59):** pg-boss queues per domain; each job wrapper: timeout, try/catch, retry policy, audit record JOB-number; worker heartbeat every 30 seconds; self-heal job checks stale heartbeats, restarts jobs, alerts admin; sandbox = separate process with limited permissions for untrusted work (file scan, media handling).

**News and About (F24, F25):** cron pulls RSS and API feeds, dedupes by URL hash, stores, serves paged; admin can post own items; About page video slots with lazy loading.

**Notifications (F26):** event table drives sender; channel preferences per user; push via Expo, WhatsApp templates, email, SMS provider.

**Tools (F27):** service reminders (mileage or date based job), booking (slots table, conflict check), checklists (templates and user state), estimator (labor and part price rules), tyre and oil guide (lookup by vehicle).

**Language and currency (F29):** i18n files English and Swahili; currency toggle uses stored rate.

**Offline (F30):** expo-sqlite mirror of catalog subset, cart and pending actions; sync on reconnect as in section 5.

**Security (F31, F33-F38):** AES-256-GCM field encryption with key from env and key id for rotation; TLS enforced; Zod on all inputs; helmet; CSRF for web admin; upload pipeline: type sniff, size limit, rename, scan, store; security_events table feeds Security agent and automatic responses; backups by scheduled dump job plus Supabase backups, restore script tested; data export and delete endpoints with consent log.

**Admin (F39-F44):** web app for management; dashboards from SQL views; audit table with sequential prefixed IDs via database sequences plus random key; exports with exceljs and pdfkit; alerts via notification system; same screens in-app for admin role.

**Quality (F47-F58, F60):** pino logs with request ID; error boundaries; global handlers; Vitest and Supertest tests for auth, orders, payments, validation, agents; k6 script for 1,000 virtual users; GitHub Actions runs lint, typecheck, tests, build; performance budget check on bundle size and API latency.

## 8. Data flows

- **Order:** app, API, validate, fraud score, transaction (reserve stock, order, payment), STK push, callback, mark paid, queue receipt and notifications, audit.
- **Diagnosis:** app, API, brain rules scoring, optional AI, parts lookup, response, audit.
- **Attack:** request, rate limit or bot check fails, security_event, Security agent scores, auto block or lock, admin alert, audit.
- **Failure:** provider timeout, retry, breaker opens, fallback answer, admin alert, reconcile job repairs state.

## 9. Completion method

Build in the order in INSTRUCTIONS.md. For each feature: implement, test, run, tick TODO.md, update BUILD_STATE.md, verify against CHECKLIST.md.
