# Meru Garage

Genuine automotive parts store for Kenya with AI support, AI self-diagnosis, autonomous agents, live news and a full admin panel. Runs on Android, iOS and web from one codebase.

## Features

- Store: 5,000+ genuine parts, search by name, part number, VIN, make/model/year and photo, reviews, compare, wishlist, discounts, bundles
- Payments: M-Pesa STK push, cash on delivery, PDF receipts by WhatsApp and email
- AI: support bot (English, Swahili), diagnostic agent (text, photo, warning lights, sound, OBD), agents hub
- Agents: Sales, Stock, Support, Fraud, Security, Reports, Diagnostics, with admin approval for high-risk actions
- Tools: service reminders, VIN decoder, garage booking, checklists, price estimator, tyre and oil guide
- Content: live news, About page with videos
- Admin: dashboards, reports, numbered audit trail, alerts, PDF and Excel export
- Security: layered encryption, sandboxing, rate limiting, fraud detection, automatic attack response
- Design: white and deep black, glass UI, animated engine-and-gear background, morphing line icons, dark default

## Stack

Expo React Native, TypeScript, Express, Drizzle ORM, PostgreSQL (Supabase), Clerk, Vercel.

## Structure

```
apps/mobile      Expo app (Android, iOS, web)
apps/api         Express API, agents, workers
apps/admin       Admin web panel
packages/shared  Types, schemas, constants
docs/            AI_PROMPT.md, architecture notes
scripts/         seed, backup, restore, load test
```

## Quick start

```
git clone <repo-url> && cd meru-garage
cp .env.example .env
npm install
npm run db:migrate
npm run db:seed
npm run dev
```

## Environment variables

Set in `.env` (never commit): DATABASE_URL, CLERK_SECRET_KEY, CLERK_PUBLISHABLE_KEY, MPESA_CONSUMER_KEY, MPESA_CONSUMER_SECRET, MPESA_SHORTCODE, MPESA_PASSKEY, MPESA_CALLBACK_URL, WHATSAPP_TOKEN, WHATSAPP_PHONE_ID, AI_API_KEY, SMTP_URL, ENCRYPTION_KEY, SENTRY_DSN (optional).

## Scripts

`dev`, `build`, `test`, `lint`, `typecheck`, `db:migrate`, `db:seed`, `backup`, `restore`, `loadtest`.

## Documents

| File | Purpose |
|---|---|
| INSTRUCTIONS.md | Rules the AI and developers must follow |
| TODO.md | Every feature to build, by module |
| CHECKLIST.md | Verification and release gates |
| BUILD_STATE.md | Live progress memory (AI updates) |
| DECISIONS.md | Decisions and exceptions log |
| docs/AI_PROMPT.md | Full one-shot build prompt |

## Contact

mzeeraiji@gmail.com, 0781037456
