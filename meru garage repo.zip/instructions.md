# INSTRUCTIONS

Rules for any AI or developer working in this repo.

## Read order at the start of every session
1. docs/AI_PROMPT.md (full specification)
2. INSTRUCTIONS.md (this file)
3. BUILD_STATE.md (current progress and next step)
4. TODO.md and CHECKLIST.md

## Connect to AI

- Claude Code: open the repo folder, run `claude`. Create `CLAUDE.md` in the root containing: "Read docs/AI_PROMPT.md, INSTRUCTIONS.md, BUILD_STATE.md, TODO.md before any work. Follow them exactly."
- Cursor: open the folder, add a rule file `.cursor/rules/project.mdc` with the same sentence, set it to always apply.
- Start message: "Follow docs/AI_PROMPT.md and complete everything. Update BUILD_STATE.md as you go."
- Resume message: "Continue from BUILD_STATE.md."

## Work rules

- Build the whole app. No stubs, mocks, TODO comments or truncated code.
- Decide alone, record in DECISIONS.md, never stop to ask.
- One module at a time: build, run, test, tick in TODO.md, update BUILD_STATE.md, then move on.
- Do not change the stack, folder layout or naming mid-build.
- Define types and API contracts once in packages/shared and import everywhere.
- Files under 300 lines. Reuse components. No duplicated logic.
- Near a context or output limit: finish the current file, update BUILD_STATE.md, output "CHECKPOINT: resume from F##", stop.
- Never rewrite finished work when resuming.

## Code standards

- Strict TypeScript, no `any`, no ts-ignore, no empty catch.
- Validate all input with Zod. Parameterized queries only.
- Secrets only in env. Never log secrets or personal data.
- Every record gets a prefixed sequential ID (ORD-000123, AUD-000123, JOB-000123, SEC-000123) plus hidden random key.
- UI: white and deep black only, glass panels, no emojis, reduced-motion support.
- Comments only where logic is non-obvious.

## Error handling

- Build time: after each module run install, typecheck, lint, tests, start, and hit the feature. Fix root causes. Maximum 3 attempts per approach, then change approach.
- Runtime: timeouts, retries with backoff, circuit breakers and safe fallbacks on every external call. Idempotency keys on payments. Friendly user message with a reference ID, full trace for admin.
- AI failure or limit: fall back to rules, never show raw errors.
- Missing external keys: code against the real API, add a sandbox switch, list in .env.example and SETUP.md.
- Log every fixed bug in BUILD_STATE.md with a regression test.

## Git rules

- Branch per module: `feat/<feature-id>-<name>`. Small commits: `F12: add M-Pesa callback`.
- Never commit .env, keys or data dumps.
- Merge to main only when CHECKLIST.md items for that module pass.

## Definition of done

All F## items VERIFIED, tests pass, Android and web builds succeed, seed loads, admin works end to end, SETUP.md and DEPLOY.md exist.
