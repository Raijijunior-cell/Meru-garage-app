# CHECKLIST

Every box must be ticked before release.

## Per module (repeat for each)
- [ ] Installs, typechecks and lints with zero errors
- [ ] Tests written and passing
- [ ] Runs locally, feature used end to end
- [ ] Errors handled, no empty catch
- [ ] Audit records written where required
- [ ] TODO.md and BUILD_STATE.md updated

## Design
- [ ] Only white and deep black, no emojis
- [ ] Glass UI, animated background, morphing icons on every screen
- [ ] Dark, light and system themes work
- [ ] Reduced-motion and low-end fallback work
- [ ] 60fps on a mid-range Android phone

## Store and payments
- [ ] 5,000+ parts seeded, search under 1s
- [ ] Order flow: cart, checkout, pay, receipt, status, return
- [ ] M-Pesa success, failure, timeout and lost callback all handled
- [ ] No double charge (idempotency proven by test)
- [ ] Stock never goes negative

## AI and agents
- [ ] Support bot answers, tracks orders, hands over, works in English and Swahili
- [ ] Diagnostics work for text, photo, warning lights, sound, OBD
- [ ] AI limit reached falls back to rules cleanly
- [ ] High-risk agent actions wait for admin approval
- [ ] Worker crash restarts and retries the job

## Security
- [ ] Every API route checks token and role
- [ ] Input validation on all routes
- [ ] Rate limits and bot blocking tested
- [ ] Uploads scanned and type-checked
- [ ] Sensitive fields encrypted at rest
- [ ] Attack simulation triggers block, lock, alert
- [ ] No secrets in repo or logs
- [ ] Dependency audit clean
- [ ] Data export and deletion work

## Admin
- [ ] Every record has a numbered traceable ID
- [ ] All required events logged and searchable
- [ ] Reports export to PDF and Excel
- [ ] Alerts arrive in-app, WhatsApp and email

## Resilience
- [ ] Offline browse, cart and sync tested
- [ ] Database outage degrades to read-only cache
- [ ] Health endpoints and self-healing job run
- [ ] Backup and restore tested
- [ ] Load test passes target for 1,000 users

## Release
- [ ] Android and web builds succeed
- [ ] Play Store listing steps complete
- [ ] SETUP.md and DEPLOY.md verified on a clean machine
- [ ] Final verification table shows all F## VERIFIED
